export TYPEORM_CONNECTION=postgres
export TYPEORM_ENTITIES=./src/modules/domain/**/*.entity.ts
export TYPEORM_HOST=database-2.ctqrwmfggda4.us-west-2.rds.amazonaws.com
export TYPEORM_PORT=5432
export TYPEORM_USERNAME=postgres
export TYPEORM_PASSWORD=postgres
export TYPEORM_DATABASE=postgres
export TYPEORM_MIGRATIONS=./src/migrations/*.ts
export TYPEORM_MIGRATIONS_DIR=./src/migrations

